package org.meb.conquest.service.impl;

import java.io.Serializable;

import org.meb.conquest.service.api.CardSetService;

public class CardSetServiceImpl extends SearchServiceImpl implements CardSetService, Serializable {

	private static final long serialVersionUID = -3917684297662777248L;
}
