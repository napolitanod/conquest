package org.meb.conquest.service.api;


public interface CardSetService extends SearchService {

}
