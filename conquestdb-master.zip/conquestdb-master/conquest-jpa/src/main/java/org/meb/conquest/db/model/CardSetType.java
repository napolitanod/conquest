package org.meb.conquest.db.model;

public enum CardSetType {

	CORE, WAR_PACK, DELUXE
}
