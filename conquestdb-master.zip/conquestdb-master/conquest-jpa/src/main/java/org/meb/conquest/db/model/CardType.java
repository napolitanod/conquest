package org.meb.conquest.db.model;

public enum CardType {

	ARMY, ATTACHMENT, EVENT, PLANET, SUPPORT, SYNAPSE, TOKEN, WARLORD;
}