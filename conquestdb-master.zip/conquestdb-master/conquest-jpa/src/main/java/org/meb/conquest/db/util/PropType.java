package org.meb.conquest.db.util;

public enum PropType {
	
	JPA, JPA_DATA
};