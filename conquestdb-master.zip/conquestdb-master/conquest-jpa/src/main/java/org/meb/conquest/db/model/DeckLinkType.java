package org.meb.conquest.db.model;

public enum DeckLinkType {

	PUBLIC
}
